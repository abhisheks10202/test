from django.shortcuts import render,HttpResponse
# import home2 from 'templates/home2.html'
# Create your views here.
def home(request):
    return render(request,'home2.html')
def signin(request):
    return render(request,'signin2.html')
def contactus(request):
    return render(request,'contactus.html')
