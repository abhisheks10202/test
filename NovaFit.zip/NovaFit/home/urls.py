from django.contrib import admin
from django.urls import path,include
from home import views

urlpatterns = [
    # path('', include('home.urls')),
    # path('/', include('blog.urls'))
    path("", views.home,name="home"),
    path("contactus", views.contactus,name="contactus"),
    path("signin", views.signin,name="signin"),
    # path("admin/", admin.site.urls),
]